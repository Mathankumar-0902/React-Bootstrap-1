import { ListGroup, Button, Col } from "react-bootstrap";
import { RiDeleteBin6Line } from "react-icons/ri";

const AppointmentInfo = ({ appointment, onDeleteAppointment }) => {
  return (
    <>
      <ListGroup.Item>
        <p>
          <small>Date: </small>
          {appointment.aptDate}
        </p>
        <p>
          <strong>First Name: </strong>
          {appointment.firstName}
        </p>
        <p>
          <strong>Last Name: </strong>
          {appointment.lastName}
        </p>
        <p>
          <strong>Notes: </strong>
          {appointment.aptNotes}
        </p>
        <Col md='4'>
          <Button
            size='sm'
            variant='danger'
            className='align-items-center d-inline-flex'
            onClick={() => onDeleteAppointment(appointment.id)}
          >
            <RiDeleteBin6Line className='me-2' />
            Delete
          </Button>
        </Col>
      </ListGroup.Item>
    </>
  );
};

export default AppointmentInfo;
