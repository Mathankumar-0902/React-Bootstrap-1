import {
  InputGroup,
  FormControl,
  Dropdown,
  DropdownButton,
} from "react-bootstrap";
import { BsCheck2 } from "react-icons/bs";

const DropdownItems = ({
  onSortByChange,
  sortBy,
  orderBy,
  onOrderByChange,
}) => {
  return (
    <>
      <DropdownButton variant='info' title='sort'>
        <Dropdown.Item href='#' onClick={() => onSortByChange("firstName")}>
          First Name
          {sortBy == "firstName" && <BsCheck2 className='float-end' />}
        </Dropdown.Item>
        <Dropdown.Item href='#' onClick={() => onSortByChange("lastName")}>
          Last Name
          {sortBy == "lastName" && <BsCheck2 className='float-end' />}
        </Dropdown.Item>
        <Dropdown.Item href='#' onClick={() => onSortByChange("aptDate")}>
          Appoint Date
          {sortBy == "aptDate" && <BsCheck2 className='float-end' />}
        </Dropdown.Item>
        <Dropdown.Divider />
        <Dropdown.Item href='#' onClick={() => onOrderByChange("asc")}>
          ASC
          {orderBy == "asc" && <BsCheck2 className='float-end' />}
        </Dropdown.Item>
        <Dropdown.Item href='#' onClick={() => onorderByChange("desc")}>
          DESC
          {orderBy == "desc" && <BsCheck2 className='float-end' />}
        </Dropdown.Item>
      </DropdownButton>
    </>
  );
};

const Search = ({
  query,
  onQueryChange,
  orderBy,
  onOrderByChange,
  sortBy,
  onSortByChange,
}) => {
  return (
    <InputGroup className='mb-3'>
      <FormControl
        placeholder='search'
        onChange={(event) => {
          onQueryChange(event.target.value);
        }}
        value={query}
      />
      <DropdownItems
        orderBy={orderBy}
        onOrderByChange={(myOrder) => onOrderByChange(myOrder)}
        sortBy={sortBy}
        onSortByChange={(mySort) => onSortByChange(mySort)}
      />
    </InputGroup>
  );
};

export default Search;
