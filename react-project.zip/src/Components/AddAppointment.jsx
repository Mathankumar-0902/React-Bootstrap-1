import { Card, Form, Row, Col, Button } from "react-bootstrap";
import { useState } from "react";

const AddAppointment = () => {
  const clearData = {
    firstName: "",
    lastName: "",
    aptDate: "",
    aptTime: "",
    aptNotes: "",
  };
  let [toggleSomething, setToggleAppear] = useState(false);
  let [formData, setFormData] = useState(clearData);

  function formDataPublish() {
    const appointmentInfo = {
      id: lastId + 1,
      firstName: formData.firstName,
      lastName: formData.lastName,
      aptDate: formData.aptDate + " " + formData.aptTime,
      aptNotes: formData.aptNotes,
    };
    onSendAppointment(appointmentInfo);
    setFormData(clearData);
    setToggleAppear(!toggleSomething);
  }
  return (
    <>
      <Col md='8'>
        <Card className='mb-3'>
          <Card.Header>
            Add Appointment
            <Button
              className='float-end small'
              onClick={() => setToggleAppear(!toggleSomething)}
            >
              +
            </Button>
          </Card.Header>
          {toggleSomething && (
            <Card.Body>
              <Form>
                <Row className='mb-2'>
                  <Col md='6'>
                    <Form.Group>
                      <Form.Label>First Name</Form.Label>
                      <Form.Control type='text' placeholder='First Name' />
                    </Form.Group>
                  </Col>
                  <Col md='6'>
                    <Form.Group className='mb-2'>
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control type='text' placeholder='Last Name' />
                    </Form.Group>
                  </Col>
                </Row>
                <Form.Group className='mb-2'>
                  <Form.Label>Appointment Date</Form.Label>
                  <Form.Control type='date' />
                </Form.Group>
                <Form.Group className='mb-2'>
                  <Form.Label>Appointment Time</Form.Label>
                  <Form.Control type='time' />
                </Form.Group>
                <Form.Group className='mb-2'>
                  <Form.Label>Comments</Form.Label>
                  <Form.Control as='textarea' placeholder='comments' />
                </Form.Group>
                <Button variant='info' className='mt-3'>
                  Submit
                </Button>
              </Form>
            </Card.Body>
          )}
        </Card>
      </Col>
    </>
  );
};

export default AddAppointment;
