import "bootstrap/dist/css/bootstrap.min.css";
import { BsFillClipboardMinusFill } from "react-icons/bs";
import { Row, Col, Container, Card, ListGroup } from "react-bootstrap";
import Search from "./Components/Search";
import AddAppointment from "./Components/AddAppointment";
import AppointmentInfo from "./Components/AppointmentInfo";
import { useCallback, useEffect, useState } from "react";

function App() {
  let [appointmentList, setAppointmentList] = useState([]);
  let [query, setQuery] = useState("");
  let [sortBy, setSortBy] = useState("firstName");
  let [orderBy, setOrderBy] = useState("asc");

  const filterAppointment = appointmentList
    .filter((item) => {
      return (
        item.firstName.toLowerCase().includes(query.toLocaleLowerCase()) ||
        item.firstName.toLowerCase().includes(query.toLocaleLowerCase()) ||
        item.aptNotes.toLowerCase().includes(query.toLocaleLowerCase())
      );
    })
    .sort((a, b) => {
      let order = orderBy === "asc" ? 1 : -1;
      return a[sortBy].toLowerCase < b[sortBy].toLowerCase
        ? -1 * order
        : 1 * order;
    });

  const fetchData = useCallback(() => {
    fetch("./data.json")
      .then((response) => response.json())
      .then((data) => setAppointmentList(data));
  }, []);
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <div className='App'>
      <Container>
        <Row>
          <Col>
            <h1 className='fw-light text-center mt-3 align-items-center  d-inline-flex '>
              <BsFillClipboardMinusFill className='me-2' />
              Vite Bootstrap APP
            </h1>
          </Col>
        </Row>
        <Row className='justify-content-center'>
          <AddAppointment />
        </Row>
        <Row className='justify-content-center'>
          <Col md='4'>
            <Search
              query={query}
              onQueryChange={(myQuery) => setQuery(myQuery)}
              orderBy={orderBy}
              onOrderByChange={(myOrder) => setOrderBy(myOrder)}
              sortBy={sortBy}
              onSortByChange={(mySort) => setSortBy(mySort)}
            />
          </Col>
        </Row>
        <Row className='justify-content-center'>
          <Col md='8'>
            <Card>
              <Card.Header>Appointments</Card.Header>
              <ListGroup variant='flush'>
                {filterAppointment.map((appointment) => (
                  <AppointmentInfo
                    key={appointment.id}
                    appointment={appointment}
                    onDeleteAppointment={(appointmentid) =>
                      setAppointmentList(
                        appointmentList.filter(
                          (appointment) => appointment.id !== appointmentid
                        )
                      )
                    }
                  />
                ))}
              </ListGroup>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default App;
